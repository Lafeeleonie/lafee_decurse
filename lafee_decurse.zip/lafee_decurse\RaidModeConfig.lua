local _, addon = ...
local L = addon.L

local function CreateRaidSettingsCard(content, panel)
    if panel.RaidSettingsCard then
        return
    end

    local card = CreateFrame("Frame", nil, content, "BackdropTemplate")
    card:SetHeight(196)
    card:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    card:SetBackdropColor(0.035, 0.045, 0.065, 0.92)
    card:SetBackdropBorderColor(0.16, 0.28, 0.40, 0.95)

    local title = card:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", card, "TOPLEFT", 16, -12)
    title:SetText(L.SECTION_RAID or "Raid")
    title:SetTextColor(0.55, 0.90, 1)

    local label = card:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    label:SetPoint("LEFT", card, "TOPLEFT", 16, -50)
    label:SetText(L.RAID_GROUP_NUMBER_SIDE or "Raid group number")

    local dropdown = CreateFrame("DropdownButton", nil, card, "WowStyle1DropdownTemplate")
    dropdown:SetPoint("TOPLEFT", card, "TOPLEFT", 245, -34)
    dropdown:SetWidth(285)
    dropdown:SetDefaultText(L.RAID_GROUP_NUMBER_SIDE or "Raid group number")
    dropdown:SetupMenu(function(_, rootDescription)
        local options = {
            { value = addon.RAID_GROUP_NUMBER_NONE, text = L.RAID_GROUP_NUMBER_NONE or "None" },
            { value = addon.RAID_GROUP_NUMBER_LEFT, text = L.GROWTH_LEFT or "Left" },
            { value = addon.RAID_GROUP_NUMBER_RIGHT, text = L.GROWTH_RIGHT or "Right" },
        }

        local function IsSelected(value)
            return addon:GetRaidGroupNumberSide() == value
        end

        local function SetSelected(value)
            if not addon:SetRaidGroupNumberSide(value) then
                addon:RefreshConfigurationPanel()
            end
        end

        for _, option in ipairs(options) do
            rootDescription:CreateRadio(option.text, IsSelected, SetSelected, option.value)
        end
    end)

    local roleIconsCheckbox = CreateFrame("CheckButton", nil, card, "UICheckButtonTemplate")
    roleIconsCheckbox:SetPoint("TOPLEFT", card, "TOPLEFT", 14, -72)
    roleIconsCheckbox:SetScript("OnClick", function(self)
        if not addon:SetRaidRoleIconsVisible(self:GetChecked() == true) then
            addon:RefreshConfigurationPanel()
        end
    end)

    local roleIconsLabel = card:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    roleIconsLabel:SetPoint("LEFT", roleIconsCheckbox, "RIGHT", 4, 0)
    roleIconsLabel:SetText(L.SHOW_RAID_ROLE_ICONS or "Show raid role icons")

    local scaleLabel = card:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    scaleLabel:SetPoint("LEFT", card, "TOPLEFT", 16, -121)
    scaleLabel:SetText(L.RAID_FRAME_SCALE or "Raid frame scale")

    local scaleSlider = CreateFrame("Frame", nil, card, "MinimalSliderWithSteppersTemplate")
    scaleSlider:SetSize(250, 40)
    scaleSlider:SetPoint("TOPLEFT", card, "TOPLEFT", 260, -102)
    scaleSlider:Init(
        addon:GetRaidFrameScale(),
        addon.MIN_RAID_FRAME_SCALE,
        addon.MAX_RAID_FRAME_SCALE,
        15,
        {
            [MinimalSliderWithSteppersMixin.Label.Right] = function(value)
                return string.format("%d%%", math.floor((value * 100) + 0.5))
            end,
            [MinimalSliderWithSteppersMixin.Label.Min] = function()
                return "50%"
            end,
            [MinimalSliderWithSteppersMixin.Label.Max] = function()
                return "200%"
            end,
        }
    )
    scaleSlider.Slider:HookScript("OnValueChanged", function(_, value)
        if scaleSlider.ignoreValueChanged then
            return
        end
        local scale = math.floor((value * 10) + 0.5) / 10
        if math.abs(scale - addon:GetRaidFrameScale()) > 0.001 then
            addon:SetRaidFrameScale(scale)
        end
    end)

    local testCheckbox = CreateFrame("CheckButton", nil, card, "UICheckButtonTemplate")
    testCheckbox:SetPoint("TOPLEFT", card, "TOPLEFT", 14, -154)
    testCheckbox:SetScript("OnClick", function(self)
        if not addon:SetRaidTestMode(self:GetChecked() == true) then
            addon:RefreshConfigurationPanel()
        end
    end)

    local testLabel = card:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    testLabel:SetPoint("LEFT", testCheckbox, "RIGHT", 4, 0)
    testLabel:SetText(L.RAID_TEST_MODE or "Raid test mode")

    panel.RaidSettingsCard = card
    panel.RaidGroupNumberSideDropdown = dropdown
    panel.RaidRoleIconsCheckbox = roleIconsCheckbox
    panel.RaidScaleSlider = scaleSlider
    panel.RaidTestCheckbox = testCheckbox
    addon:LayoutConfigurationCards()
end

local function FindSettingsContent(panel)
    for _, child in ipairs({ panel:GetChildren() }) do
        if child:IsObjectType("ScrollFrame") and child.GetScrollChild then
            local content = child:GetScrollChild()
            if content then
                return content
            end
        end
    end
    return nil
end

local BaseCreateConfigurationPanel = addon.CreateConfigurationPanel
function addon:CreateConfigurationPanel(...)
    local result = BaseCreateConfigurationPanel(self, ...)
    local panel = self.configurationPanel
    if panel then
        local content = FindSettingsContent(panel)
        if content then
            CreateRaidSettingsCard(content, panel)
            self:RefreshConfigurationPanel()
        end
    end
    return result
end

local BaseRefreshConfigurationPanel = addon.RefreshConfigurationPanel
function addon:RefreshConfigurationPanel(...)
    local result = BaseRefreshConfigurationPanel(self, ...)
    local panel = self.configurationPanel
    if not panel then
        return result
    end

    local dropdown = panel.RaidGroupNumberSideDropdown
    if dropdown and dropdown.GenerateMenu then
        dropdown:GenerateMenu()
    end

    if panel.RaidTestCheckbox then
        panel.RaidTestCheckbox:SetChecked(self:IsRaidTestModeEnabled())
        panel.RaidTestCheckbox:SetEnabled(not IsInRaid() and not InCombatLockdown())
    end

    if panel.RaidRoleIconsCheckbox then
        panel.RaidRoleIconsCheckbox:SetChecked(self:AreRaidRoleIconsShown())
        panel.RaidRoleIconsCheckbox:SetEnabled(not InCombatLockdown())
    end

    if panel.RaidScaleSlider then
        panel.RaidScaleSlider.ignoreValueChanged = true
        panel.RaidScaleSlider:SetValue(self:GetRaidFrameScale())
        panel.RaidScaleSlider.ignoreValueChanged = nil
    end

    return result
end
